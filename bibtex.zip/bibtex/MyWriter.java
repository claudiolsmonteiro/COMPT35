import Entry.*;

import java.io.*;

public class MyWriter extends BibTexBaseListener {

    PrintWriter writer;
    MyEntry my_entry;
    String key, entry;
    int line;


    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterParse(BibTexParser.ParseContext ctx) {
        try {
            writer = new PrintWriter("teste.html", "UTF-8");
            writer.println("<html>" +
                    "<head>\n" +
                    "<meta charset=\"utf-8\">\n" +
                    "    <title>Bibliography</title>\n" +
                    "</head>\n" +
                    "<body>");
            writer.println("<div><table><tbody>");
        } catch (IOException e) {
            System.out.println("file nor found exception");
        }
        line = 1;
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitParse(BibTexParser.ParseContext ctx) {
        writer.println("</tbody></table></div>");
        writer.println("</body></html>");
        writer.close();
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterEntry(BibTexParser.EntryContext ctx) {
        key = ctx.Name().getText();
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitEntry(BibTexParser.EntryContext ctx) {

        writer.println("<tr><td>[" + line + "]</td>" + my_entry.toHTML() + "</tr>");
        line++;
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterEntryType(BibTexParser.EntryTypeContext ctx) {
        //System.out.println("Entrou no entryType");
        switch (ctx.getText().toLowerCase()) {
            case "@article{":
                entry = "article";
                my_entry = new MyArticle(key);
                break;
            case "@book{":
                entry = "book";
                my_entry = new MyBook(key);
                break;
            case "@booklet{":
                entry = "booklet";
                my_entry = new MyBookLet(key);
                break;
            case "@inbook{":
                entry = "inbook";
                my_entry = new MyInBook(key);
                break;
            case "@incollection{":
                entry = "incollection";
                my_entry = new MyInCollection(key);
                break;
            case "@inproceedings{":
                entry = "inproceedings";
                my_entry = new MyInProceedings(key);
                break;
            case "@manual{":
                entry = "manual";
                my_entry = new MyManual(key);
                break;
            case "@mastersthesis{":
                entry = "mastersthesis";
                my_entry = new MyMastersthesis(key);
                break;
            case "@misc{":
                entry = "misc";
                my_entry = new MyMisc(key);
                break;
            case "@phdthesis{":
                entry = "phdthesis";
                my_entry = new MyPhdthesis(key);
                break;
            case "@proceedings{":
                entry = "proceedings";
                my_entry = new MyProceedings(key);
                break;
            case "@techreport{":
                entry = "techreport";
                my_entry = new MyTechReport(key);
                break;
            case "@unpublished{":
                entry = "unpublished";
                my_entry = new MyUnpublished(key);
                break;
        }
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitEntryType(BibTexParser.EntryTypeContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterEntryTag(BibTexParser.EntryTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitEntryTag(BibTexParser.EntryTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterAddressTag(BibTexParser.AddressTagContext ctx) {
        String address = ctx.String().getText();
        address = address.replace("{", "");
        address = address.replace("}", "");
        my_entry.set_address(address);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitAddressTag(BibTexParser.AddressTagContext ctx) {

    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterAuthorTag(BibTexParser.AuthorTagContext ctx) {
        String author = ctx.String().getText();
        author = author.replace("{", "");
        author = author.replace("}", "");
        my_entry.set_author(author);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitAuthorTag(BibTexParser.AuthorTagContext ctx) { //System.out.println("Saiu do authorTag");
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterBooktitleTag(BibTexParser.BooktitleTagContext ctx) {
        String booktitle = ctx.String().getText();
        booktitle = booktitle.replace("{", "");
        booktitle = booktitle.replace("}", "");
        my_entry.set_booktitle(booktitle);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitBooktitleTag(BibTexParser.BooktitleTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterChapterTag(BibTexParser.ChapterTagContext ctx) {
        String chapter = ctx.String().getText();
        chapter = chapter.replace("{", "");
        chapter = chapter.replace("}", "");
        my_entry.set_chapter(chapter);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitChapterTag(BibTexParser.ChapterTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterCrossrefTag(BibTexParser.CrossrefTagContext ctx) {
        String crossref = ctx.String().getText();
        crossref = crossref.replace("{", "");
        crossref = crossref.replace("}", "");
        my_entry.set_crossref(crossref);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitCrossrefTag(BibTexParser.CrossrefTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterEditionTag(BibTexParser.EditionTagContext ctx) {
        String edition = ctx.String().getText();
        edition = edition.replace("{", "");
        edition = edition.replace("}", "");
        my_entry.set_edition(edition);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitEditionTag(BibTexParser.EditionTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterEditorTag(BibTexParser.EditorTagContext ctx) {
        String editor = ctx.String().getText();
        editor = editor.replace("{", "");
        editor = editor.replace("}", "");
        my_entry.set_editor(editor);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitEditorTag(BibTexParser.EditorTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterHowpublishedTag(BibTexParser.HowpublishedTagContext ctx) {
        String howpublished = ctx.String().getText();
        howpublished = howpublished.replace("{", "");
        howpublished = howpublished.replace("}", "");
        my_entry.set_howpublished(howpublished);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitHowpublishedTag(BibTexParser.HowpublishedTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterInstitutionTag(BibTexParser.InstitutionTagContext ctx) {
        String institution = ctx.String().getText();
        institution = institution.replace("{", "");
        institution = institution.replace("}", "");
        my_entry.set_institution(institution);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitInstitutionTag(BibTexParser.InstitutionTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterJournalTag(BibTexParser.JournalTagContext ctx) {
        String journal = ctx.String().getText();
        journal = journal.replace("{", "");
        journal = journal.replace("}", "");
        my_entry.set_journal(journal);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitJournalTag(BibTexParser.JournalTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterKeyTag(BibTexParser.KeyTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitKeyTag(BibTexParser.KeyTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterMonthTag(BibTexParser.MonthTagContext ctx) {
        String month = ctx.String().getText();
        month = month.replace("{", "");
        month = month.replace("}", "");
        my_entry.set_month(month);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitMonthTag(BibTexParser.MonthTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterNoteTag(BibTexParser.NoteTagContext ctx) {
        String note = ctx.String().getText();
        note = note.replace("{", "");
        note = note.replace("}", "");
        my_entry.set_note(note);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitNoteTag(BibTexParser.NoteTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterNumberTag(BibTexParser.NumberTagContext ctx) {
        String number = ctx.Number().getText();
        number = number.replace("{", "");
        number = number.replace("}", "");
        my_entry.set_number(number);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitNumberTag(BibTexParser.NumberTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterOrganizationTag(BibTexParser.OrganizationTagContext ctx) {
        String organization = ctx.String().getText();
        organization = organization.replace("{", "");
        organization = organization.replace("}", "");
        my_entry.set_organization(organization);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitOrganizationTag(BibTexParser.OrganizationTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterPagesTag(BibTexParser.PagesTagContext ctx) {
        String pages = ctx.String().getText();
        pages = pages.replace("{", "");
        pages = pages.replace("}", "");
        my_entry.set_pages(pages);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitPagesTag(BibTexParser.PagesTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterPublisherTag(BibTexParser.PublisherTagContext ctx) {
        String publisher = ctx.String().getText();
        publisher = publisher.replace("{", "");
        publisher = publisher.replace("}", "");
        my_entry.set_publisher(publisher);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitPublisherTag(BibTexParser.PublisherTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */

    @Override
    public void enterSchoolTag(BibTexParser.SchoolTagContext ctx) {
        String school = ctx.String().getText();
        school = school.replace("{", "");
        school = school.replace("}", "");
        my_entry.set_school(school);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitSchoolTag(BibTexParser.SchoolTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterSeriesTag(BibTexParser.SeriesTagContext ctx) {
        String author = ctx.String().getText();
        author = author.replace("{", "");
        author = author.replace("}", "");
        my_entry.set_author(author);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitSeriesTag(BibTexParser.SeriesTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterTitleTag(BibTexParser.TitleTagContext ctx) {
        String title = ctx.String().getText();
        title = title.replace("{", "");
        title = title.replace("}", "");
        my_entry.set_title(title);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitTitleTag(BibTexParser.TitleTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterTypeTag(BibTexParser.TypeTagContext ctx) {
        String type = ctx.String().getText();

        type = type.replace("{", "");
        type = type.replace("}", "");
        my_entry.set_type(type);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitTypeTag(BibTexParser.TypeTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterVolumeTag(BibTexParser.VolumeTagContext ctx) {
        String volume = ctx.getText();
        volume = volume.toLowerCase();
        volume = volume.replace("volume =", "");
        volume = volume.replace("{", "");
        volume = volume.replace("}", "");
        my_entry.set_volume(volume);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitVolumeTag(BibTexParser.VolumeTagContext ctx) {
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void enterYearTag(BibTexParser.YearTagContext ctx) {
        String year = ctx.Number().getText();
        year = year.replace("{", "");
        year = year.replace("}", "");
        my_entry.set_year(year);
    }

    /**
     * {@inheritDoc}
     * <p>
     * <p>The default implementation does nothing.</p>
     */
    @Override
    public void exitYearTag(BibTexParser.YearTagContext ctx) {
    }

}