package Entry;

public abstract class MyEntry{
	
	private String name;
	
	public MyEntry(String name) {
		this.name = name;
	}
	
	public abstract void set_address(String a);
	public abstract void set_author(String a);
	public abstract void set_booktitle(String b);
	public abstract void set_chapter(String c);
	public abstract void set_crossref(String c);
	public abstract void set_edition(String e);
	public abstract void set_editor(String e);
	public abstract void set_howpublished(String h);
	public abstract void set_institution(String i);
	public abstract void set_journal(String j);
	public abstract void set_month(String m);
	public abstract void set_note(String n);
	public abstract void set_number(String n);
	public abstract void set_organization(String o);
	public abstract void set_pages(String p);
	public abstract void set_publisher(String p);
	public abstract void set_school(String s);
	public abstract void set_series(String s);
	public abstract void set_title(String t);
	public abstract void set_type(String t);
	public abstract void set_volume(String v);
	public abstract void set_year(String y);


    public abstract String toString();
    public abstract String toHTML();
}