package Entry;

/**
 * Created by Eduardo on 06/06/2015.
 */
public class MyTechReport extends MyEntry{

    private String address, author, institution, month, note, number, title, type, year;

    public MyTechReport(String name) {
        super(name);
    }

    public void set_address(String a){address = a;}
    public void set_author(String a){author = a;}
    public void set_booktitle(String b){}
    public void set_chapter(String c){}
    public void set_crossref(String c){}
    public void set_edition(String e){}
    public void set_editor(String e){}
    public void set_howpublished(String h){}
    public void set_institution(String i){institution = i;}
    public void set_journal(String j){}
    public void set_month(String m){month = m;}
    public void set_note(String n){note = n;}
    public void set_number(String n){number = n;}
    public void set_organization(String o){}
    public void set_pages(String p){}
    public void set_publisher(String p){}
    public void set_school(String s){}
    public void set_series(String s){}
    public void set_title(String t){title = t;}
    public void set_type(String t){type = t;}
    public void set_volume(String v){}
    public void set_year(String y){year = y;}


    public String toString(){return null;}

    @Override
    public String toHTML() {
        String ret;
        ret  = "<td class=\"bibtexitem\">\n" + author + ".\n <em>" + title + "</em>.\n ";

        if(type != null)
            ret += type + " ";
        if(number != null)
            ret +="("+number+")";
        if(address != null)
            ret += address + ", ";
        if(month != null)
            ret +=  month + " " + year + ".";
        else
            ret += year;
        if(note != null)
            ret +=" "+ note+".\n";

        ret += "\n</td>";

        return ret;
    }
}
