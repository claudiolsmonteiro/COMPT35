package Entry;

import org.antlr.v4.runtime.*;


/**
 * Created by Eduardo on 10/06/2015.
 */
public class MyErrorListener extends BaseErrorListener {
    public static MyErrorListener INSTANCE = new MyErrorListener();

    @Override
    public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e){
        System.err.println("Error on line "+line+":"+charPositionInLine+" "+msg+".");
    }
}
