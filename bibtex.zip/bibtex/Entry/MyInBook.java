package Entry;

/**
 * Created by Eduardo on 06/06/2015.
 */
public class MyInBook extends MyEntry{

    public MyInBook(String name) {
        super(name);
    }

    private String address, author, chapter, edition, editor, month, note, number, pages, publisher, series, title, type, volume, year;

    public void set_address(String a){address = a;}
    public void set_author(String a){author = a;}
    public void set_booktitle(String b){}
    public void set_chapter(String c){chapter = c;}
    public void set_crossref(String c){}
    public void set_edition(String e){edition = e;}
    public void set_editor(String e){editor = e;}
    public void set_howpublished(String h){}
    public void set_institution(String i){}
    public void set_journal(String j){}
    public void set_month(String m){month = m;}
    public void set_note(String n){note = n;}
    public void set_number(String n){number = n;}
    public void set_organization(String o){}
    public void set_pages(String p){pages = p;}
    public void set_publisher(String p){publisher = p;}
    public void set_school(String s){}
    public void set_series(String s){series = s;}
    public void set_title(String t){title = t;}
    public void set_type(String t){type = t;}
    public void set_volume(String v){volume = v;}
    public void set_year(String y){year = y;}


    public String toString(){
        String ret = new String();
        if(author!=null)
            ret = ret + author + ", " + title;
        else
            ret = ret + editor + ", " + title;

        ret = ret + chapter + " " + pages + " " + publisher;
        if(edition != null)
            ret = ret + ", " + edition;
        if(series != null)
            ret = ret + ", " + series;
        if(volume != null)
            ret = ret + ", " + volume;
        if(number!=null)
            ret = ret + "(" + number + ")";
        if(type!=null)
            ret = ret + "(" + type + ")";
        if(month!=null)
            ret = ret + ", " + month + " " + year;
        else
            ret = ret + ", " + year;
        if(note != null)
            ret = ret + ", " + note;

        return ret;
    }

    public String toHTML(){
        String ret;
        ret  = "<td class=\"bibtexitem\">\n" + author + ".\n <em>" + title + "</em>.\n ";

        if(series != null)
            ret += series + ". ";

        ret += publisher + ", ";

        if(edition != null)
            ret += edition + " edition ";
        if(volume != null)
            ret += "volume " + volume;
        if(number != null)
            ret +="("+number+")";
        if(edition != null || volume != null || number != null)
            ret += ", ";
        if(chapter != null)
            ret += "chapter " + chapter + ", ";
        if(pages != null)
            ret += "pages " + pages + ". ";
        if(publisher != null)
            ret += publisher + ", ";
        if(address != null)
            ret += address + ", ";
        if(month != null)
            ret +=  month + " " + year + ".";
        else
            ret += year;
        if(note != null)
            ret +=" "+ note+".\n";

        ret += "\n</td>";

        return ret;
    }


}
