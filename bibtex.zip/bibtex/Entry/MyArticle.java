package Entry;

public class MyArticle extends MyEntry{
	
	private String author, title, journal, year, volume, number, pages, month, note;
	
	public MyArticle(String name){
		super(name);
	}

    public void set_author(String a){
        author = a;
    }
	public void set_title(String t){
		title = t;
	}
	public void set_journal(String j){
		journal = j;
	}
	public void set_year(String y){
		year = y;
	}
	public void set_volume(String v){
		volume = v;
	}
	public void set_number(String n){
		number = n;
	}
	public void set_pages(String p){
		pages = p;
	}
	public void set_month(String m){
		month = m;
	}
	public void set_note(String n){
		note = n;
	}
	
	public String toString(){
		String ret = new String(author + ". " + title + ". " + journal);
		if(volume != null)
			ret = ret + ", " + volume;
		if(number!=null)
			ret = ret + "(" + number + ")";
		if(pages!=null)
			ret = ret + ": " + pages;
		if(month!=null)
			ret = ret + ", " + month + " " + year;
		else
			ret = ret + ", " + year;
		
		return ret;
		
	}

    public String toHTML(){
        String ret = "<td class=\"bibtexitem\">\n" + author +".\n " + title + ".\n <em>"+journal+"</em>, ";

        if(volume != null)
            ret += "volume " + volume;
        if(number != null)
            ret += "(" + number + ")";

        if((volume != null || number != null) && pages != null)
            ret += ":" + pages + ",\n";
        else
            ret += ",\n";

        if(month != null)
            ret += " "+month+" "+year+".\n";
        else
            ret += " " + year +".\n";

        if(note != null)
            ret +=  " " + note + ".\n";

        ret += "</td>";

        return ret;
    }
		
	public void set_address(String a){};
	public void set_booktitle(String b){};
	public void set_chapter(String c){};
	public void set_crossref(String c){};
	public void set_edition(String e){};
	public void set_editor(String e){};
	public void set_howpublished(String h){};
	public void set_institution(String i){};
	public void set_organization(String o){};
	public void set_publisher(String p){};
	public void set_series(String s){};
	public void set_school(String s){};
	public void set_type(String t){};
}