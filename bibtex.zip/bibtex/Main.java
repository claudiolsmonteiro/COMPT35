import Entry.MyErrorListener;
import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
	public static void main(String[] args) throws Exception {

        try {
            BibTexLexer lexer = new BibTexLexer(new ANTLRFileStream("M:\\FEUP\\4Ano\\COMP\\Repositorio\\comp_bibtex1415\\src\\teste.bib"));
		BibTexParser parser = new BibTexParser(new CommonTokenStream(lexer));

        lexer.removeErrorListeners();
        lexer.addErrorListener(MyErrorListener.INSTANCE);
        parser.removeErrorListeners();
        parser.addErrorListener(MyErrorListener.INSTANCE);
		ParseTree tree = parser.parse();

		ParseTreeWalker walker = new ParseTreeWalker();
		
		MyListener listener = new MyListener();
		walker.walk(listener, tree);
		
		MyWriter writer = new MyWriter();
		walker.walk(writer, tree);

        }catch (FileNotFoundException e){
            System.out.print(e);
        }
	}
}