import java.util.ArrayList;
import java.io.*;

public class MyListener extends BibTexBaseListener {
 
	ArrayList<String> required, optional;
	String entry, key;
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterParse(BibTexParser.ParseContext ctx) { //System.out.println("Entrou no Parse");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitParse(BibTexParser.ParseContext ctx) { //System.out.println("Saiu do Parse");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEntry(BibTexParser.EntryContext ctx) { key = ctx.Name().getText();//System.out.println("Entrou no Entry");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override 
	public void exitEntry(BibTexParser.EntryContext ctx) {
		//System.out.println("Saiu do Entry");
		if(required.size()>0){
			for(int i = 0; i < required.size(); i++){
				System.out.println("missing: "+required.get(i)+" on "+key);
			}
		}	
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override
    public void enterEntryType(BibTexParser.EntryTypeContext ctx) {
		required = new ArrayList<String>();
		optional = new ArrayList<String>();
		switch (ctx.getText().toLowerCase()){
		case "@article{":
			entry = "article";
			required.add("author");
			required.add("title");
			required.add("journal");
			required.add("year");
			optional.add("volume");
			optional.add("number");
			optional.add("pages");
			optional.add("month");
			optional.add("note");
			break;
		case "@book{":
			entry = "book";
			required.add("author");
			required.add("editor");
			required.add("title");
			required.add("publisher");
			required.add("year");
			optional.add("volume");
			optional.add("number");
			optional.add("series");
			optional.add("address");
			optional.add("edition");
			optional.add("month");
			optional.add("note");
			break;
		case "@booklet{":
			entry = "booklet";
			required.add("title");
			optional.add("author");
			optional.add("howpublished");
			optional.add("address");
			optional.add("month");
			optional.add("year");
			optional.add("note");
			break;
		case "@inbook{":
			entry = "inbook";
			required.add("author");
			required.add("editor");
			required.add("title");
			required.add("chapter");
			required.add("pages");
			optional.add("chapter");   //and/or
			optional.add("pages");		//and/or
			required.add("publisher");
			required.add("year");
			optional.add("volume");
			optional.add("number");
			optional.add("series");
			optional.add("type");
			optional.add("address");
			optional.add("edition");
			optional.add("month");
			optional.add("note");
			break;
		case "@incollection{":
			entry = "incollection";
			required.add("author");
			required.add("title");
			required.add("booktitle");
			required.add("publisher");
			required.add("year");
			optional.add("editor");
			optional.add("volume");
			optional.add("number");
			optional.add("series");
			optional.add("type");
			optional.add("chapter");
			optional.add("pages");
			optional.add("address");
			optional.add("edition");
			optional.add("month");
			optional.add("note");
			break;
		case "@inproceedings{":
			entry = "inproceedings";
			required.add("author");
			required.add("title");
			required.add("booktitle");
			required.add("year");
			optional.add("editor");
			optional.add("volume");
			optional.add("number");
			optional.add("series");
			optional.add("pages");
			optional.add("address");
			optional.add("month");
			optional.add("organization");
			optional.add("publisher");
			optional.add("note");
			break;
		case "@manual{":
			entry = "manual";
			required.add("title");
			optional.add("author");
			optional.add("year");
			optional.add("address");
			optional.add("month");
			optional.add("organization");
            optional.add("edition");
			optional.add("note");
			break;
		case "@mastersthesis{":
			entry = "mastersthesis";
			required.add("title");
			required.add("author");
			required.add("school");
			required.add("year");
			optional.add("type");
			optional.add("address");
			optional.add("month");
			optional.add("note");
			break;
		case "@misc{":
			entry = "misc";
			optional.add("author");
			optional.add("title");
			optional.add("howpublished");
			optional.add("month");
			optional.add("year");
			optional.add("note");
			break;
		case "@phdthesis{":
			entry = "phdthesis";
			required.add("title");
			required.add("author");
			required.add("school");
			required.add("year");
			optional.add("type");
			optional.add("address");
			optional.add("month");
			optional.add("note");
			break;
		case "@proceedings{":
			entry = "proceedings";
			required.add("title");
			required.add("year");
			optional.add("editor");
			optional.add("volume");
			optional.add("number");
			optional.add("series");
			optional.add("address");
			optional.add("month");
			optional.add("organization");
			optional.add("publisher");
			optional.add("note");
			break;
		case "@techreport{":
			entry = "techreport";
			required.add("author");
			required.add("title");
			required.add("institution");
			required.add("year");
			optional.add("type");
			optional.add("number");
			optional.add("address");
			optional.add("month");
			optional.add("note");
			break;
		case "@unpublished{":
			entry = "unpublished";
			required.add("author");
			required.add("title");
			required.add("note");
			optional.add("month");
			optional.add("year");
			break;
		}
    }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override 
	public void exitEntryType(BibTexParser.EntryTypeContext ctx) {
		//System.out.println("Saiu do EntryType");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEntryTag(BibTexParser.EntryTagContext ctx) { //System.out.println("Entrou no entryTag"); 
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitEntryTag(BibTexParser.EntryTagContext ctx) { //System.out.println("Saiu do EntryTag");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterAddressTag(BibTexParser.AddressTagContext ctx) {
		if(required.contains("address"))
			required.remove("address");
		else if(optional.contains("address"))
			optional.remove("address");
		else
			System.out.println("Nao pode ter address("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitAddressTag(BibTexParser.AddressTagContext ctx) {
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterAuthorTag(BibTexParser.AuthorTagContext ctx) {
		if(required.contains("author")){
			required.remove("author");
			if(required.contains("editor")){
				required.remove("editor");
			}
		}
		else if(optional.contains("author"))
			optional.remove("author");
		else
			System.out.println("Nao pode ter author ("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitAuthorTag(BibTexParser.AuthorTagContext ctx) { //System.out.println("Saiu do authorTag");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterBooktitleTag(BibTexParser.BooktitleTagContext ctx) {
		if(required.contains("booktitle"))
			required.remove("booktitle");
		else if(optional.contains("booktitle"))
			optional.remove("booktitle");
		else
			System.out.println("Nao pode ter booktitle("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitBooktitleTag(BibTexParser.BooktitleTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterChapterTag(BibTexParser.ChapterTagContext ctx) {
		if(required.contains("chapter")){
			required.remove("chapter");
			if(required.contains("pages"))
				required.remove("pages");
			if(optional.contains("chapter"))     //and/or
				optional.remove("chapter");
		}
		else if(optional.contains("chapter"))
			optional.remove("chapter");
		else
			System.out.println("Nao pode ter chapter("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitChapterTag(BibTexParser.ChapterTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterCrossrefTag(BibTexParser.CrossrefTagContext ctx) {
		if(required.contains("crossref"))
			required.remove("crossref");
		else if(optional.contains("crossref"))
			optional.remove("crossref");
		else
			System.out.println("Nao pode ter crossref("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitCrossrefTag(BibTexParser.CrossrefTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEditionTag(BibTexParser.EditionTagContext ctx) {
		if(required.contains("edition"))
			required.remove("edition");
		else if(optional.contains("edition"))
			optional.remove("edition");
		else
			System.out.println("Nao pode ter edition("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitEditionTag(BibTexParser.EditionTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEditorTag(BibTexParser.EditorTagContext ctx) {
		if(required.contains("editor")){
			required.remove("editor");
			if(required.contains("author")){
				required.remove("author");
			}
		}
		else if(optional.contains("editor"))
			optional.remove("editor");
		else
			System.out.println("Nao pode ter editor("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitEditorTag(BibTexParser.EditorTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterHowpublishedTag(BibTexParser.HowpublishedTagContext ctx) {
		if(required.contains("howpublished"))
			required.remove("howpublished");
		else if(optional.contains("howpublished"))
			optional.remove("howpublished");
		else
			System.out.println("Nao pode ter howpublished("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitHowpublishedTag(BibTexParser.HowpublishedTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterInstitutionTag(BibTexParser.InstitutionTagContext ctx) {
		if(required.contains("institution"))
			required.remove("institution");
		else if(optional.contains("institution"))
			optional.remove("institution");
		else
			System.out.println("Nao pode ter institution("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitInstitutionTag(BibTexParser.InstitutionTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterJournalTag(BibTexParser.JournalTagContext ctx) {
		if(required.contains("journal"))
			required.remove("journal");
		else if(optional.contains("journal"))
			optional.remove("journal");
		else
			System.out.println("Nao pode ter journal("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitJournalTag(BibTexParser.JournalTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterKeyTag(BibTexParser.KeyTagContext ctx) {
		if(required.contains("key"))
			required.remove("key");
		else if(optional.contains("key"))
			optional.remove("key");
		else
			System.out.println("Nao pode ter key("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitKeyTag(BibTexParser.KeyTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMonthTag(BibTexParser.MonthTagContext ctx) {
		if(required.contains("month"))
			required.remove("month");
		else if(optional.contains("month"))
			optional.remove("month");
		else
			System.out.println("Nao pode ter month("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMonthTag(BibTexParser.MonthTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNoteTag(BibTexParser.NoteTagContext ctx) {
		if(required.contains("note"))
			required.remove("note");
		else if(optional.contains("note"))
			optional.remove("note");
		else
			System.out.println("Nao pode ter note("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNoteTag(BibTexParser.NoteTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumberTag(BibTexParser.NumberTagContext ctx) {
		if(required.contains("number"))
			required.remove("number");
		else if(optional.contains("number"))
			optional.remove("number");
		else
			System.out.println("Nao pode ter number("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumberTag(BibTexParser.NumberTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterOrganizationTag(BibTexParser.OrganizationTagContext ctx) {
		if(required.contains("organization"))
			required.remove("organization");
		else if(optional.contains("organization"))
			optional.remove("organization");
		else
			System.out.println("Nao pode ter organization("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitOrganizationTag(BibTexParser.OrganizationTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPagesTag(BibTexParser.PagesTagContext ctx) {
		if(required.contains("pages")){
			required.remove("pages");
			if(required.contains("chapter"))
				required.remove("chapter");
			if(optional.contains("pages"))
				optional.remove("pages");
		}
		else if(optional.contains("pages"))
			optional.remove("pages");
		else
			System.out.println("Nao pode ter pages("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPagesTag(BibTexParser.PagesTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPublisherTag(BibTexParser.PublisherTagContext ctx) {
		if(required.contains("publisher"))
			required.remove("publisher");
		else if(optional.contains("publisher"))
			optional.remove("publisher");
		else
			System.out.println("Nao pode ter publisher("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPublisherTag(BibTexParser.PublisherTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterSchoolTag(BibTexParser.SchoolTagContext ctx) {
		if(required.contains("school"))
			required.remove("school");
		else if(optional.contains("school"))
			optional.remove("school");
		else
			System.out.println("Nao pode ter school("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitSchoolTag(BibTexParser.SchoolTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterSeriesTag(BibTexParser.SeriesTagContext ctx) {
		if(required.contains("series"))
			required.remove("series");
		else if(optional.contains("series"))
			optional.remove("series");
		else
			System.out.println("Nao pode ter series("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitSeriesTag(BibTexParser.SeriesTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTitleTag(BibTexParser.TitleTagContext ctx) {
		if(required.contains("title"))
			required.remove("title");
		else if(optional.contains("title"))
			optional.remove("title");
		else
			System.out.println("Nao pode ter title("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTitleTag(BibTexParser.TitleTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTypeTag(BibTexParser.TypeTagContext ctx) {
		if(required.contains("type"))
			required.remove("type");
		else if(optional.contains("type"))
			optional.remove("type");
		else
			System.out.println("Nao pode ter type("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTypeTag(BibTexParser.TypeTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterVolumeTag(BibTexParser.VolumeTagContext ctx) {
		if(required.contains("volume"))
			required.remove("volume");
		else if(optional.contains("volume"))
			optional.remove("volume");
		else
			System.out.println("Nao pode ter volume("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitVolumeTag(BibTexParser.VolumeTagContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterYearTag(BibTexParser.YearTagContext ctx) {
		if(required.contains("year"))
			required.remove("year");
		else if(optional.contains("year"))
			optional.remove("year");
		else
			System.out.println("Nao pode ter year("+key+")");
	}
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitYearTag(BibTexParser.YearTagContext ctx) { }
 
}