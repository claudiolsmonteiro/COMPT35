// Generated from BibTex.g4 by ANTLR 4.2
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link BibTexParser}.
 */
public interface BibTexListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link BibTexParser#publisherTag}.
	 * @param ctx the parse tree
	 */
	void enterPublisherTag(@NotNull BibTexParser.PublisherTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#publisherTag}.
	 * @param ctx the parse tree
	 */
	void exitPublisherTag(@NotNull BibTexParser.PublisherTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#volumeTag}.
	 * @param ctx the parse tree
	 */
	void enterVolumeTag(@NotNull BibTexParser.VolumeTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#volumeTag}.
	 * @param ctx the parse tree
	 */
	void exitVolumeTag(@NotNull BibTexParser.VolumeTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#monthTag}.
	 * @param ctx the parse tree
	 */
	void enterMonthTag(@NotNull BibTexParser.MonthTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#monthTag}.
	 * @param ctx the parse tree
	 */
	void exitMonthTag(@NotNull BibTexParser.MonthTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#numberTag}.
	 * @param ctx the parse tree
	 */
	void enterNumberTag(@NotNull BibTexParser.NumberTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#numberTag}.
	 * @param ctx the parse tree
	 */
	void exitNumberTag(@NotNull BibTexParser.NumberTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#editorTag}.
	 * @param ctx the parse tree
	 */
	void enterEditorTag(@NotNull BibTexParser.EditorTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#editorTag}.
	 * @param ctx the parse tree
	 */
	void exitEditorTag(@NotNull BibTexParser.EditorTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#institutionTag}.
	 * @param ctx the parse tree
	 */
	void enterInstitutionTag(@NotNull BibTexParser.InstitutionTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#institutionTag}.
	 * @param ctx the parse tree
	 */
	void exitInstitutionTag(@NotNull BibTexParser.InstitutionTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#schoolTag}.
	 * @param ctx the parse tree
	 */
	void enterSchoolTag(@NotNull BibTexParser.SchoolTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#schoolTag}.
	 * @param ctx the parse tree
	 */
	void exitSchoolTag(@NotNull BibTexParser.SchoolTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#journalTag}.
	 * @param ctx the parse tree
	 */
	void enterJournalTag(@NotNull BibTexParser.JournalTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#journalTag}.
	 * @param ctx the parse tree
	 */
	void exitJournalTag(@NotNull BibTexParser.JournalTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#entryType}.
	 * @param ctx the parse tree
	 */
	void enterEntryType(@NotNull BibTexParser.EntryTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#entryType}.
	 * @param ctx the parse tree
	 */
	void exitEntryType(@NotNull BibTexParser.EntryTypeContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#noteTag}.
	 * @param ctx the parse tree
	 */
	void enterNoteTag(@NotNull BibTexParser.NoteTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#noteTag}.
	 * @param ctx the parse tree
	 */
	void exitNoteTag(@NotNull BibTexParser.NoteTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#editionTag}.
	 * @param ctx the parse tree
	 */
	void enterEditionTag(@NotNull BibTexParser.EditionTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#editionTag}.
	 * @param ctx the parse tree
	 */
	void exitEditionTag(@NotNull BibTexParser.EditionTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#keyTag}.
	 * @param ctx the parse tree
	 */
	void enterKeyTag(@NotNull BibTexParser.KeyTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#keyTag}.
	 * @param ctx the parse tree
	 */
	void exitKeyTag(@NotNull BibTexParser.KeyTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#typeTag}.
	 * @param ctx the parse tree
	 */
	void enterTypeTag(@NotNull BibTexParser.TypeTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#typeTag}.
	 * @param ctx the parse tree
	 */
	void exitTypeTag(@NotNull BibTexParser.TypeTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#addressTag}.
	 * @param ctx the parse tree
	 */
	void enterAddressTag(@NotNull BibTexParser.AddressTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#addressTag}.
	 * @param ctx the parse tree
	 */
	void exitAddressTag(@NotNull BibTexParser.AddressTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#yearTag}.
	 * @param ctx the parse tree
	 */
	void enterYearTag(@NotNull BibTexParser.YearTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#yearTag}.
	 * @param ctx the parse tree
	 */
	void exitYearTag(@NotNull BibTexParser.YearTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#parse}.
	 * @param ctx the parse tree
	 */
	void enterParse(@NotNull BibTexParser.ParseContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#parse}.
	 * @param ctx the parse tree
	 */
	void exitParse(@NotNull BibTexParser.ParseContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#crossrefTag}.
	 * @param ctx the parse tree
	 */
	void enterCrossrefTag(@NotNull BibTexParser.CrossrefTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#crossrefTag}.
	 * @param ctx the parse tree
	 */
	void exitCrossrefTag(@NotNull BibTexParser.CrossrefTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#titleTag}.
	 * @param ctx the parse tree
	 */
	void enterTitleTag(@NotNull BibTexParser.TitleTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#titleTag}.
	 * @param ctx the parse tree
	 */
	void exitTitleTag(@NotNull BibTexParser.TitleTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#booktitleTag}.
	 * @param ctx the parse tree
	 */
	void enterBooktitleTag(@NotNull BibTexParser.BooktitleTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#booktitleTag}.
	 * @param ctx the parse tree
	 */
	void exitBooktitleTag(@NotNull BibTexParser.BooktitleTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#seriesTag}.
	 * @param ctx the parse tree
	 */
	void enterSeriesTag(@NotNull BibTexParser.SeriesTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#seriesTag}.
	 * @param ctx the parse tree
	 */
	void exitSeriesTag(@NotNull BibTexParser.SeriesTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#entry}.
	 * @param ctx the parse tree
	 */
	void enterEntry(@NotNull BibTexParser.EntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#entry}.
	 * @param ctx the parse tree
	 */
	void exitEntry(@NotNull BibTexParser.EntryContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#howpublishedTag}.
	 * @param ctx the parse tree
	 */
	void enterHowpublishedTag(@NotNull BibTexParser.HowpublishedTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#howpublishedTag}.
	 * @param ctx the parse tree
	 */
	void exitHowpublishedTag(@NotNull BibTexParser.HowpublishedTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#organizationTag}.
	 * @param ctx the parse tree
	 */
	void enterOrganizationTag(@NotNull BibTexParser.OrganizationTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#organizationTag}.
	 * @param ctx the parse tree
	 */
	void exitOrganizationTag(@NotNull BibTexParser.OrganizationTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#chapterTag}.
	 * @param ctx the parse tree
	 */
	void enterChapterTag(@NotNull BibTexParser.ChapterTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#chapterTag}.
	 * @param ctx the parse tree
	 */
	void exitChapterTag(@NotNull BibTexParser.ChapterTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#authorTag}.
	 * @param ctx the parse tree
	 */
	void enterAuthorTag(@NotNull BibTexParser.AuthorTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#authorTag}.
	 * @param ctx the parse tree
	 */
	void exitAuthorTag(@NotNull BibTexParser.AuthorTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#entryTag}.
	 * @param ctx the parse tree
	 */
	void enterEntryTag(@NotNull BibTexParser.EntryTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#entryTag}.
	 * @param ctx the parse tree
	 */
	void exitEntryTag(@NotNull BibTexParser.EntryTagContext ctx);

	/**
	 * Enter a parse tree produced by {@link BibTexParser#pagesTag}.
	 * @param ctx the parse tree
	 */
	void enterPagesTag(@NotNull BibTexParser.PagesTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link BibTexParser#pagesTag}.
	 * @param ctx the parse tree
	 */
	void exitPagesTag(@NotNull BibTexParser.PagesTagContext ctx);
}