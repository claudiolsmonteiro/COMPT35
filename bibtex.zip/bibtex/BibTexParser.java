// Generated from BibTex.g4 by ANTLR 4.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class BibTexParser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		Assign=1, Comma=2, CloseBrace=3, String=4, ArticleType=5, BookType=6, 
		BookletType=7, InbookType=8, IncollectionType=9, InproceedingsType=10, 
		ManualType=11, MastersthesisType=12, MiscType=13, PhdthesisType=14, ProceedingsType=15, 
		TechreportType=16, UnpublishedType=17, AddressField=18, AuthorField=19, 
		BooktitleField=20, ChapterField=21, CrossrefField=22, EditionField=23, 
		EditorField=24, HowpublishedField=25, InstitutionField=26, JournalField=27, 
		KeyField=28, MonthField=29, NoteField=30, NumberField=31, OrganizationField=32, 
		PagesField=33, PublisherField=34, SchoolField=35, SeriesField=36, TitleField=37, 
		TypeField=38, VolumeField=39, YearField=40, Number=41, Name=42, Spaces=43;
	public static final String[] tokenNames = {
		"<INVALID>", "'='", "','", "'}'", "String", "ArticleType", "BookType", 
		"BookletType", "InbookType", "IncollectionType", "InproceedingsType", 
		"ManualType", "MastersthesisType", "MiscType", "PhdthesisType", "ProceedingsType", 
		"TechreportType", "UnpublishedType", "AddressField", "AuthorField", "BooktitleField", 
		"ChapterField", "CrossrefField", "EditionField", "EditorField", "HowpublishedField", 
		"InstitutionField", "JournalField", "KeyField", "MonthField", "NoteField", 
		"NumberField", "OrganizationField", "PagesField", "PublisherField", "SchoolField", 
		"SeriesField", "TitleField", "TypeField", "VolumeField", "YearField", 
		"Number", "Name", "Spaces"
	};
	public static final int
		RULE_parse = 0, RULE_entry = 1, RULE_entryType = 2, RULE_entryTag = 3, 
		RULE_addressTag = 4, RULE_authorTag = 5, RULE_booktitleTag = 6, RULE_chapterTag = 7, 
		RULE_crossrefTag = 8, RULE_editionTag = 9, RULE_editorTag = 10, RULE_howpublishedTag = 11, 
		RULE_institutionTag = 12, RULE_journalTag = 13, RULE_keyTag = 14, RULE_monthTag = 15, 
		RULE_noteTag = 16, RULE_numberTag = 17, RULE_organizationTag = 18, RULE_pagesTag = 19, 
		RULE_publisherTag = 20, RULE_schoolTag = 21, RULE_seriesTag = 22, RULE_titleTag = 23, 
		RULE_typeTag = 24, RULE_volumeTag = 25, RULE_yearTag = 26;
	public static final String[] ruleNames = {
		"parse", "entry", "entryType", "entryTag", "addressTag", "authorTag", 
		"booktitleTag", "chapterTag", "crossrefTag", "editionTag", "editorTag", 
		"howpublishedTag", "institutionTag", "journalTag", "keyTag", "monthTag", 
		"noteTag", "numberTag", "organizationTag", "pagesTag", "publisherTag", 
		"schoolTag", "seriesTag", "titleTag", "typeTag", "volumeTag", "yearTag"
	};

	@Override
	public String getGrammarFileName() { return "BibTex.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public BibTexParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ParseContext extends ParserRuleContext {
		public EntryContext entry(int i) {
			return getRuleContext(EntryContext.class,i);
		}
		public TerminalNode Comma(int i) {
			return getToken(BibTexParser.Comma, i);
		}
		public TerminalNode EOF() { return getToken(BibTexParser.EOF, 0); }
		public List<EntryContext> entry() {
			return getRuleContexts(EntryContext.class);
		}
		public List<TerminalNode> Comma() { return getTokens(BibTexParser.Comma); }
		public ParseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parse; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterParse(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitParse(this);
		}
	}

	public final ParseContext parse() throws RecognitionException {
		ParseContext _localctx = new ParseContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_parse);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(67);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ArticleType) | (1L << BookType) | (1L << BookletType) | (1L << InbookType) | (1L << IncollectionType) | (1L << InproceedingsType) | (1L << ManualType) | (1L << MastersthesisType) | (1L << MiscType) | (1L << PhdthesisType) | (1L << ProceedingsType) | (1L << TechreportType) | (1L << UnpublishedType))) != 0)) {
				{
				setState(54); entry();
				setState(61);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,1,_ctx);
				while ( _alt!=2 && _alt!=-1 ) {
					if ( _alt==1 ) {
						{
						{
						setState(56);
						_la = _input.LA(1);
						if (_la==Comma) {
							{
							setState(55); match(Comma);
							}
						}

						setState(58); entry();
						}
						} 
					}
					setState(63);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,1,_ctx);
				}
				setState(65);
				_la = _input.LA(1);
				if (_la==Comma) {
					{
					setState(64); match(Comma);
					}
				}

				}
			}

			setState(69); match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EntryContext extends ParserRuleContext {
		public EntryTypeContext entryType() {
			return getRuleContext(EntryTypeContext.class,0);
		}
		public TerminalNode Comma(int i) {
			return getToken(BibTexParser.Comma, i);
		}
		public List<EntryTagContext> entryTag() {
			return getRuleContexts(EntryTagContext.class);
		}
		public TerminalNode CloseBrace() { return getToken(BibTexParser.CloseBrace, 0); }
		public TerminalNode Name() { return getToken(BibTexParser.Name, 0); }
		public List<TerminalNode> Comma() { return getTokens(BibTexParser.Comma); }
		public EntryTagContext entryTag(int i) {
			return getRuleContext(EntryTagContext.class,i);
		}
		public EntryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entry; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitEntry(this);
		}
	}

	public final EntryContext entry() throws RecognitionException {
		EntryContext _localctx = new EntryContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_entry);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(71); entryType();
			setState(72); match(Name);
			setState(77);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==Comma) {
				{
				{
				setState(73); match(Comma);
				setState(74); entryTag();
				}
				}
				setState(79);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(80); match(CloseBrace);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EntryTypeContext extends ParserRuleContext {
		public TerminalNode BookletType() { return getToken(BibTexParser.BookletType, 0); }
		public TerminalNode MastersthesisType() { return getToken(BibTexParser.MastersthesisType, 0); }
		public TerminalNode InproceedingsType() { return getToken(BibTexParser.InproceedingsType, 0); }
		public TerminalNode UnpublishedType() { return getToken(BibTexParser.UnpublishedType, 0); }
		public TerminalNode ManualType() { return getToken(BibTexParser.ManualType, 0); }
		public TerminalNode MiscType() { return getToken(BibTexParser.MiscType, 0); }
		public TerminalNode IncollectionType() { return getToken(BibTexParser.IncollectionType, 0); }
		public TerminalNode ProceedingsType() { return getToken(BibTexParser.ProceedingsType, 0); }
		public TerminalNode PhdthesisType() { return getToken(BibTexParser.PhdthesisType, 0); }
		public TerminalNode ArticleType() { return getToken(BibTexParser.ArticleType, 0); }
		public TerminalNode BookType() { return getToken(BibTexParser.BookType, 0); }
		public TerminalNode InbookType() { return getToken(BibTexParser.InbookType, 0); }
		public TerminalNode TechreportType() { return getToken(BibTexParser.TechreportType, 0); }
		public EntryTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entryType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterEntryType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitEntryType(this);
		}
	}

	public final EntryTypeContext entryType() throws RecognitionException {
		EntryTypeContext _localctx = new EntryTypeContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_entryType);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(82);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ArticleType) | (1L << BookType) | (1L << BookletType) | (1L << InbookType) | (1L << IncollectionType) | (1L << InproceedingsType) | (1L << ManualType) | (1L << MastersthesisType) | (1L << MiscType) | (1L << PhdthesisType) | (1L << ProceedingsType) | (1L << TechreportType) | (1L << UnpublishedType))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EntryTagContext extends ParserRuleContext {
		public AuthorTagContext authorTag() {
			return getRuleContext(AuthorTagContext.class,0);
		}
		public JournalTagContext journalTag() {
			return getRuleContext(JournalTagContext.class,0);
		}
		public TypeTagContext typeTag() {
			return getRuleContext(TypeTagContext.class,0);
		}
		public InstitutionTagContext institutionTag() {
			return getRuleContext(InstitutionTagContext.class,0);
		}
		public SchoolTagContext schoolTag() {
			return getRuleContext(SchoolTagContext.class,0);
		}
		public EditorTagContext editorTag() {
			return getRuleContext(EditorTagContext.class,0);
		}
		public VolumeTagContext volumeTag() {
			return getRuleContext(VolumeTagContext.class,0);
		}
		public NoteTagContext noteTag() {
			return getRuleContext(NoteTagContext.class,0);
		}
		public MonthTagContext monthTag() {
			return getRuleContext(MonthTagContext.class,0);
		}
		public YearTagContext yearTag() {
			return getRuleContext(YearTagContext.class,0);
		}
		public BooktitleTagContext booktitleTag() {
			return getRuleContext(BooktitleTagContext.class,0);
		}
		public HowpublishedTagContext howpublishedTag() {
			return getRuleContext(HowpublishedTagContext.class,0);
		}
		public SeriesTagContext seriesTag() {
			return getRuleContext(SeriesTagContext.class,0);
		}
		public KeyTagContext keyTag() {
			return getRuleContext(KeyTagContext.class,0);
		}
		public NumberTagContext numberTag() {
			return getRuleContext(NumberTagContext.class,0);
		}
		public OrganizationTagContext organizationTag() {
			return getRuleContext(OrganizationTagContext.class,0);
		}
		public CrossrefTagContext crossrefTag() {
			return getRuleContext(CrossrefTagContext.class,0);
		}
		public EditionTagContext editionTag() {
			return getRuleContext(EditionTagContext.class,0);
		}
		public AddressTagContext addressTag() {
			return getRuleContext(AddressTagContext.class,0);
		}
		public PagesTagContext pagesTag() {
			return getRuleContext(PagesTagContext.class,0);
		}
		public PublisherTagContext publisherTag() {
			return getRuleContext(PublisherTagContext.class,0);
		}
		public ChapterTagContext chapterTag() {
			return getRuleContext(ChapterTagContext.class,0);
		}
		public TitleTagContext titleTag() {
			return getRuleContext(TitleTagContext.class,0);
		}
		public EntryTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entryTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterEntryTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitEntryTag(this);
		}
	}

	public final EntryTagContext entryTag() throws RecognitionException {
		EntryTagContext _localctx = new EntryTagContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_entryTag);
		try {
			setState(107);
			switch (_input.LA(1)) {
			case AddressField:
				enterOuterAlt(_localctx, 1);
				{
				setState(84); addressTag();
				}
				break;
			case AuthorField:
				enterOuterAlt(_localctx, 2);
				{
				setState(85); authorTag();
				}
				break;
			case BooktitleField:
				enterOuterAlt(_localctx, 3);
				{
				setState(86); booktitleTag();
				}
				break;
			case ChapterField:
				enterOuterAlt(_localctx, 4);
				{
				setState(87); chapterTag();
				}
				break;
			case CrossrefField:
				enterOuterAlt(_localctx, 5);
				{
				setState(88); crossrefTag();
				}
				break;
			case EditionField:
				enterOuterAlt(_localctx, 6);
				{
				setState(89); editionTag();
				}
				break;
			case EditorField:
				enterOuterAlt(_localctx, 7);
				{
				setState(90); editorTag();
				}
				break;
			case HowpublishedField:
				enterOuterAlt(_localctx, 8);
				{
				setState(91); howpublishedTag();
				}
				break;
			case InstitutionField:
				enterOuterAlt(_localctx, 9);
				{
				setState(92); institutionTag();
				}
				break;
			case JournalField:
				enterOuterAlt(_localctx, 10);
				{
				setState(93); journalTag();
				}
				break;
			case KeyField:
				enterOuterAlt(_localctx, 11);
				{
				setState(94); keyTag();
				}
				break;
			case MonthField:
				enterOuterAlt(_localctx, 12);
				{
				setState(95); monthTag();
				}
				break;
			case NoteField:
				enterOuterAlt(_localctx, 13);
				{
				setState(96); noteTag();
				}
				break;
			case NumberField:
				enterOuterAlt(_localctx, 14);
				{
				setState(97); numberTag();
				}
				break;
			case OrganizationField:
				enterOuterAlt(_localctx, 15);
				{
				setState(98); organizationTag();
				}
				break;
			case PagesField:
				enterOuterAlt(_localctx, 16);
				{
				setState(99); pagesTag();
				}
				break;
			case PublisherField:
				enterOuterAlt(_localctx, 17);
				{
				setState(100); publisherTag();
				}
				break;
			case SchoolField:
				enterOuterAlt(_localctx, 18);
				{
				setState(101); schoolTag();
				}
				break;
			case SeriesField:
				enterOuterAlt(_localctx, 19);
				{
				setState(102); seriesTag();
				}
				break;
			case TitleField:
				enterOuterAlt(_localctx, 20);
				{
				setState(103); titleTag();
				}
				break;
			case TypeField:
				enterOuterAlt(_localctx, 21);
				{
				setState(104); typeTag();
				}
				break;
			case VolumeField:
				enterOuterAlt(_localctx, 22);
				{
				setState(105); volumeTag();
				}
				break;
			case YearField:
				enterOuterAlt(_localctx, 23);
				{
				setState(106); yearTag();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AddressTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode AddressField() { return getToken(BibTexParser.AddressField, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public AddressTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_addressTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterAddressTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitAddressTag(this);
		}
	}

	public final AddressTagContext addressTag() throws RecognitionException {
		AddressTagContext _localctx = new AddressTagContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_addressTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(109); match(AddressField);
			setState(110); match(Assign);
			setState(111); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AuthorTagContext extends ParserRuleContext {
		public TerminalNode AuthorField() { return getToken(BibTexParser.AuthorField, 0); }
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public AuthorTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_authorTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterAuthorTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitAuthorTag(this);
		}
	}

	public final AuthorTagContext authorTag() throws RecognitionException {
		AuthorTagContext _localctx = new AuthorTagContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_authorTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(113); match(AuthorField);
			setState(114); match(Assign);
			setState(115); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BooktitleTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode BooktitleField() { return getToken(BibTexParser.BooktitleField, 0); }
		public BooktitleTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_booktitleTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterBooktitleTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitBooktitleTag(this);
		}
	}

	public final BooktitleTagContext booktitleTag() throws RecognitionException {
		BooktitleTagContext _localctx = new BooktitleTagContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_booktitleTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(117); match(BooktitleField);
			setState(118); match(Assign);
			setState(119); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ChapterTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode ChapterField() { return getToken(BibTexParser.ChapterField, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public ChapterTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_chapterTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterChapterTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitChapterTag(this);
		}
	}

	public final ChapterTagContext chapterTag() throws RecognitionException {
		ChapterTagContext _localctx = new ChapterTagContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_chapterTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(121); match(ChapterField);
			setState(122); match(Assign);
			setState(123); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CrossrefTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode CrossrefField() { return getToken(BibTexParser.CrossrefField, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public CrossrefTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_crossrefTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterCrossrefTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitCrossrefTag(this);
		}
	}

	public final CrossrefTagContext crossrefTag() throws RecognitionException {
		CrossrefTagContext _localctx = new CrossrefTagContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_crossrefTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(125); match(CrossrefField);
			setState(126); match(Assign);
			setState(127); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EditionTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode EditionField() { return getToken(BibTexParser.EditionField, 0); }
		public EditionTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_editionTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterEditionTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitEditionTag(this);
		}
	}

	public final EditionTagContext editionTag() throws RecognitionException {
		EditionTagContext _localctx = new EditionTagContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_editionTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(129); match(EditionField);
			setState(130); match(Assign);
			setState(131); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EditorTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode EditorField() { return getToken(BibTexParser.EditorField, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public EditorTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_editorTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterEditorTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitEditorTag(this);
		}
	}

	public final EditorTagContext editorTag() throws RecognitionException {
		EditorTagContext _localctx = new EditorTagContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_editorTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(133); match(EditorField);
			setState(134); match(Assign);
			setState(135); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class HowpublishedTagContext extends ParserRuleContext {
		public TerminalNode HowpublishedField() { return getToken(BibTexParser.HowpublishedField, 0); }
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public HowpublishedTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_howpublishedTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterHowpublishedTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitHowpublishedTag(this);
		}
	}

	public final HowpublishedTagContext howpublishedTag() throws RecognitionException {
		HowpublishedTagContext _localctx = new HowpublishedTagContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_howpublishedTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(137); match(HowpublishedField);
			setState(138); match(Assign);
			setState(139); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstitutionTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode InstitutionField() { return getToken(BibTexParser.InstitutionField, 0); }
		public InstitutionTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_institutionTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterInstitutionTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitInstitutionTag(this);
		}
	}

	public final InstitutionTagContext institutionTag() throws RecognitionException {
		InstitutionTagContext _localctx = new InstitutionTagContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_institutionTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(141); match(InstitutionField);
			setState(142); match(Assign);
			setState(143); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class JournalTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode JournalField() { return getToken(BibTexParser.JournalField, 0); }
		public JournalTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_journalTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterJournalTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitJournalTag(this);
		}
	}

	public final JournalTagContext journalTag() throws RecognitionException {
		JournalTagContext _localctx = new JournalTagContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_journalTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(145); match(JournalField);
			setState(146); match(Assign);
			setState(147); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class KeyTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode KeyField() { return getToken(BibTexParser.KeyField, 0); }
		public KeyTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_keyTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterKeyTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitKeyTag(this);
		}
	}

	public final KeyTagContext keyTag() throws RecognitionException {
		KeyTagContext _localctx = new KeyTagContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_keyTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(149); match(KeyField);
			setState(150); match(Assign);
			setState(151); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MonthTagContext extends ParserRuleContext {
		public TerminalNode MonthField() { return getToken(BibTexParser.MonthField, 0); }
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public MonthTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_monthTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterMonthTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitMonthTag(this);
		}
	}

	public final MonthTagContext monthTag() throws RecognitionException {
		MonthTagContext _localctx = new MonthTagContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_monthTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(153); match(MonthField);
			setState(154); match(Assign);
			setState(155); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NoteTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode NoteField() { return getToken(BibTexParser.NoteField, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public NoteTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_noteTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterNoteTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitNoteTag(this);
		}
	}

	public final NoteTagContext noteTag() throws RecognitionException {
		NoteTagContext _localctx = new NoteTagContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_noteTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(157); match(NoteField);
			setState(158); match(Assign);
			setState(159); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NumberTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode NumberField() { return getToken(BibTexParser.NumberField, 0); }
		public TerminalNode Number() { return getToken(BibTexParser.Number, 0); }
		public NumberTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numberTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterNumberTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitNumberTag(this);
		}
	}

	public final NumberTagContext numberTag() throws RecognitionException {
		NumberTagContext _localctx = new NumberTagContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_numberTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(161); match(NumberField);
			setState(162); match(Assign);
			setState(163); match(Number);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OrganizationTagContext extends ParserRuleContext {
		public TerminalNode OrganizationField() { return getToken(BibTexParser.OrganizationField, 0); }
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public OrganizationTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_organizationTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterOrganizationTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitOrganizationTag(this);
		}
	}

	public final OrganizationTagContext organizationTag() throws RecognitionException {
		OrganizationTagContext _localctx = new OrganizationTagContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_organizationTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(165); match(OrganizationField);
			setState(166); match(Assign);
			setState(167); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PagesTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode PagesField() { return getToken(BibTexParser.PagesField, 0); }
		public PagesTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pagesTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterPagesTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitPagesTag(this);
		}
	}

	public final PagesTagContext pagesTag() throws RecognitionException {
		PagesTagContext _localctx = new PagesTagContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_pagesTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(169); match(PagesField);
			setState(170); match(Assign);
			setState(171); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PublisherTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode PublisherField() { return getToken(BibTexParser.PublisherField, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public PublisherTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_publisherTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterPublisherTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitPublisherTag(this);
		}
	}

	public final PublisherTagContext publisherTag() throws RecognitionException {
		PublisherTagContext _localctx = new PublisherTagContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_publisherTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(173); match(PublisherField);
			setState(174); match(Assign);
			setState(175); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SchoolTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode SchoolField() { return getToken(BibTexParser.SchoolField, 0); }
		public SchoolTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_schoolTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterSchoolTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitSchoolTag(this);
		}
	}

	public final SchoolTagContext schoolTag() throws RecognitionException {
		SchoolTagContext _localctx = new SchoolTagContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_schoolTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(177); match(SchoolField);
			setState(178); match(Assign);
			setState(179); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SeriesTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode SeriesField() { return getToken(BibTexParser.SeriesField, 0); }
		public SeriesTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_seriesTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterSeriesTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitSeriesTag(this);
		}
	}

	public final SeriesTagContext seriesTag() throws RecognitionException {
		SeriesTagContext _localctx = new SeriesTagContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_seriesTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(181); match(SeriesField);
			setState(182); match(Assign);
			setState(183); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TitleTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode TitleField() { return getToken(BibTexParser.TitleField, 0); }
		public TitleTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_titleTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterTitleTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitTitleTag(this);
		}
	}

	public final TitleTagContext titleTag() throws RecognitionException {
		TitleTagContext _localctx = new TitleTagContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_titleTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(185); match(TitleField);
			setState(186); match(Assign);
			setState(187); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode TypeField() { return getToken(BibTexParser.TypeField, 0); }
		public TypeTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_typeTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterTypeTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitTypeTag(this);
		}
	}

	public final TypeTagContext typeTag() throws RecognitionException {
		TypeTagContext _localctx = new TypeTagContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_typeTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(189); match(TypeField);
			setState(190); match(Assign);
			setState(191); match(String);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VolumeTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode VolumeField() { return getToken(BibTexParser.VolumeField, 0); }
		public TerminalNode String() { return getToken(BibTexParser.String, 0); }
		public TerminalNode Number() { return getToken(BibTexParser.Number, 0); }
		public VolumeTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_volumeTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterVolumeTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitVolumeTag(this);
		}
	}

	public final VolumeTagContext volumeTag() throws RecognitionException {
		VolumeTagContext _localctx = new VolumeTagContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_volumeTag);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(193); match(VolumeField);
			setState(194); match(Assign);
			setState(195);
			_la = _input.LA(1);
			if ( !(_la==String || _la==Number) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class YearTagContext extends ParserRuleContext {
		public TerminalNode Assign() { return getToken(BibTexParser.Assign, 0); }
		public TerminalNode YearField() { return getToken(BibTexParser.YearField, 0); }
		public TerminalNode Number() { return getToken(BibTexParser.Number, 0); }
		public YearTagContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_yearTag; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).enterYearTag(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof BibTexListener ) ((BibTexListener)listener).exitYearTag(this);
		}
	}

	public final YearTagContext yearTag() throws RecognitionException {
		YearTagContext _localctx = new YearTagContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_yearTag);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(197); match(YearField);
			setState(198); match(Assign);
			setState(199); match(Number);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3-\u00cc\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\3\2\3\2\5\2;\n\2\3\2\7\2>\n\2\f\2\16\2"+
		"A\13\2\3\2\5\2D\n\2\5\2F\n\2\3\2\3\2\3\3\3\3\3\3\3\3\7\3N\n\3\f\3\16\3"+
		"Q\13\3\3\3\3\3\3\4\3\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5"+
		"\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\5\5n\n\5\3\6\3\6\3\6\3\6"+
		"\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\13"+
		"\3\13\3\13\3\13\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3"+
		"\17\3\17\3\17\3\17\3\20\3\20\3\20\3\20\3\21\3\21\3\21\3\21\3\22\3\22\3"+
		"\22\3\22\3\23\3\23\3\23\3\23\3\24\3\24\3\24\3\24\3\25\3\25\3\25\3\25\3"+
		"\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3\30\3\30\3\30\3\30\3\31\3\31\3"+
		"\31\3\31\3\32\3\32\3\32\3\32\3\33\3\33\3\33\3\33\3\34\3\34\3\34\3\34\3"+
		"\34\2\2\35\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\66"+
		"\2\4\3\2\7\23\4\2\6\6++\u00cb\2E\3\2\2\2\4I\3\2\2\2\6T\3\2\2\2\bm\3\2"+
		"\2\2\no\3\2\2\2\fs\3\2\2\2\16w\3\2\2\2\20{\3\2\2\2\22\177\3\2\2\2\24\u0083"+
		"\3\2\2\2\26\u0087\3\2\2\2\30\u008b\3\2\2\2\32\u008f\3\2\2\2\34\u0093\3"+
		"\2\2\2\36\u0097\3\2\2\2 \u009b\3\2\2\2\"\u009f\3\2\2\2$\u00a3\3\2\2\2"+
		"&\u00a7\3\2\2\2(\u00ab\3\2\2\2*\u00af\3\2\2\2,\u00b3\3\2\2\2.\u00b7\3"+
		"\2\2\2\60\u00bb\3\2\2\2\62\u00bf\3\2\2\2\64\u00c3\3\2\2\2\66\u00c7\3\2"+
		"\2\28?\5\4\3\29;\7\4\2\2:9\3\2\2\2:;\3\2\2\2;<\3\2\2\2<>\5\4\3\2=:\3\2"+
		"\2\2>A\3\2\2\2?=\3\2\2\2?@\3\2\2\2@C\3\2\2\2A?\3\2\2\2BD\7\4\2\2CB\3\2"+
		"\2\2CD\3\2\2\2DF\3\2\2\2E8\3\2\2\2EF\3\2\2\2FG\3\2\2\2GH\7\2\2\3H\3\3"+
		"\2\2\2IJ\5\6\4\2JO\7,\2\2KL\7\4\2\2LN\5\b\5\2MK\3\2\2\2NQ\3\2\2\2OM\3"+
		"\2\2\2OP\3\2\2\2PR\3\2\2\2QO\3\2\2\2RS\7\5\2\2S\5\3\2\2\2TU\t\2\2\2U\7"+
		"\3\2\2\2Vn\5\n\6\2Wn\5\f\7\2Xn\5\16\b\2Yn\5\20\t\2Zn\5\22\n\2[n\5\24\13"+
		"\2\\n\5\26\f\2]n\5\30\r\2^n\5\32\16\2_n\5\34\17\2`n\5\36\20\2an\5 \21"+
		"\2bn\5\"\22\2cn\5$\23\2dn\5&\24\2en\5(\25\2fn\5*\26\2gn\5,\27\2hn\5.\30"+
		"\2in\5\60\31\2jn\5\62\32\2kn\5\64\33\2ln\5\66\34\2mV\3\2\2\2mW\3\2\2\2"+
		"mX\3\2\2\2mY\3\2\2\2mZ\3\2\2\2m[\3\2\2\2m\\\3\2\2\2m]\3\2\2\2m^\3\2\2"+
		"\2m_\3\2\2\2m`\3\2\2\2ma\3\2\2\2mb\3\2\2\2mc\3\2\2\2md\3\2\2\2me\3\2\2"+
		"\2mf\3\2\2\2mg\3\2\2\2mh\3\2\2\2mi\3\2\2\2mj\3\2\2\2mk\3\2\2\2ml\3\2\2"+
		"\2n\t\3\2\2\2op\7\24\2\2pq\7\3\2\2qr\7\6\2\2r\13\3\2\2\2st\7\25\2\2tu"+
		"\7\3\2\2uv\7\6\2\2v\r\3\2\2\2wx\7\26\2\2xy\7\3\2\2yz\7\6\2\2z\17\3\2\2"+
		"\2{|\7\27\2\2|}\7\3\2\2}~\7\6\2\2~\21\3\2\2\2\177\u0080\7\30\2\2\u0080"+
		"\u0081\7\3\2\2\u0081\u0082\7\6\2\2\u0082\23\3\2\2\2\u0083\u0084\7\31\2"+
		"\2\u0084\u0085\7\3\2\2\u0085\u0086\7\6\2\2\u0086\25\3\2\2\2\u0087\u0088"+
		"\7\32\2\2\u0088\u0089\7\3\2\2\u0089\u008a\7\6\2\2\u008a\27\3\2\2\2\u008b"+
		"\u008c\7\33\2\2\u008c\u008d\7\3\2\2\u008d\u008e\7\6\2\2\u008e\31\3\2\2"+
		"\2\u008f\u0090\7\34\2\2\u0090\u0091\7\3\2\2\u0091\u0092\7\6\2\2\u0092"+
		"\33\3\2\2\2\u0093\u0094\7\35\2\2\u0094\u0095\7\3\2\2\u0095\u0096\7\6\2"+
		"\2\u0096\35\3\2\2\2\u0097\u0098\7\36\2\2\u0098\u0099\7\3\2\2\u0099\u009a"+
		"\7\6\2\2\u009a\37\3\2\2\2\u009b\u009c\7\37\2\2\u009c\u009d\7\3\2\2\u009d"+
		"\u009e\7\6\2\2\u009e!\3\2\2\2\u009f\u00a0\7 \2\2\u00a0\u00a1\7\3\2\2\u00a1"+
		"\u00a2\7\6\2\2\u00a2#\3\2\2\2\u00a3\u00a4\7!\2\2\u00a4\u00a5\7\3\2\2\u00a5"+
		"\u00a6\7+\2\2\u00a6%\3\2\2\2\u00a7\u00a8\7\"\2\2\u00a8\u00a9\7\3\2\2\u00a9"+
		"\u00aa\7\6\2\2\u00aa\'\3\2\2\2\u00ab\u00ac\7#\2\2\u00ac\u00ad\7\3\2\2"+
		"\u00ad\u00ae\7\6\2\2\u00ae)\3\2\2\2\u00af\u00b0\7$\2\2\u00b0\u00b1\7\3"+
		"\2\2\u00b1\u00b2\7\6\2\2\u00b2+\3\2\2\2\u00b3\u00b4\7%\2\2\u00b4\u00b5"+
		"\7\3\2\2\u00b5\u00b6\7\6\2\2\u00b6-\3\2\2\2\u00b7\u00b8\7&\2\2\u00b8\u00b9"+
		"\7\3\2\2\u00b9\u00ba\7\6\2\2\u00ba/\3\2\2\2\u00bb\u00bc\7\'\2\2\u00bc"+
		"\u00bd\7\3\2\2\u00bd\u00be\7\6\2\2\u00be\61\3\2\2\2\u00bf\u00c0\7(\2\2"+
		"\u00c0\u00c1\7\3\2\2\u00c1\u00c2\7\6\2\2\u00c2\63\3\2\2\2\u00c3\u00c4"+
		"\7)\2\2\u00c4\u00c5\7\3\2\2\u00c5\u00c6\t\3\2\2\u00c6\65\3\2\2\2\u00c7"+
		"\u00c8\7*\2\2\u00c8\u00c9\7\3\2\2\u00c9\u00ca\7+\2\2\u00ca\67\3\2\2\2"+
		"\b:?CEOm";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}